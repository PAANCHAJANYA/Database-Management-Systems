CREATE TABLE table_name
(
	roll_no CHAR(8) PRIMARY KEY NOT NULL,
	name VARCHAR(15) NOT NULL,
	age INT NOT NULL
);
DROP TABLE table_name;