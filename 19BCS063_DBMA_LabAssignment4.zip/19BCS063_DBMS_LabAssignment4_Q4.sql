SELECT customer_id, first_name, last_name FROM T3_CustomerDetails WHERE age >= 21 AND gender = 'M';
SELECT name FROM T3_EmployeeDetails WHERE salary>=10000 AND designation = 'Driver';
SELECT customer_id, first_name, last_name FROM T3_CustomerDetails WHERE age >= 40 OR gender = 'M'
SELECT employee_id, name FROM T3_EmployeeDetails WHERE salary>=10000 OR designation = 'Luggage Manager';
SELECT customer_id, first_name, last_name FROM T3_CustomerDetails WHERE NOT age >= 35;
SELECT bus_id FROM T3_bus WHERE NOT bus_type='Sleeper';
SELECT employee_id, name FROM T3_EmployeeDetails WHERE designation IN ('Driver', 'Cleaner');
SELECT hotel_name FROM T3_DestinationDetails WHERE city IN ('Kulu Manali', 'Burang');
SELECT employee_id, name FROM T3_EmployeeDetails WHERE salary BETWEEN 5000 AND 10000;
SELECT customer_id, CONCAT(first_name, last_name) AS full_name FROM T3_CustomerDetails WHERE age BETWEEN 21 AND 40;
