SELECT CONCAT(first_name, ' ', last_name) AS full_name FROM T3_CustomerDetails;
SELECT customer_id, phone AS contact_details FROM T3_CustomerDetails;
SELECT TOP 1 CONCAT(package_name, ', ', package_description) AS package FROM T3_PackageDetails WHERE package_name = 'MANASAROVAR';